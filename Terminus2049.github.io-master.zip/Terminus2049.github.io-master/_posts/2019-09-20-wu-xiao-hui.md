---

layout: post

title: 吴小晖案移送立案执行，没收10,500,000,000元，追缴75,248,510,000元及其孳息，拍卖变卖沪京杭等地不动产

categories: Archive

date: 2019-09-20

tags: 吴小晖

description: "吴小晖案移送立案执行，没收10,500,000,000元，追缴75,248,510,000元及其孳息，拍卖变卖沪京杭等地不动产"

---

原文来自「法律雇佣军LegalMercenary」:~~[吴小晖案移送立案执行，没收10,500,000,000元，追缴75,248,510,000元及其孳息，拍卖变卖沪京杭等地不动产。](https://archive.fo/PYogo#selection-31.1-31.20)~~

---

![01.jpg](https://i.loli.net/2019/09/22/DMlcIhCfmovYTZz.jpg)
