---

layout: post

title: 我的朋友梁自存，就这么凭空消失了。

categories: Archive

date: 2019-05-09

tags: 梁自存

description: 5月8日，广州NGOer 梁自存被警察带走。

---

原文来自微博「有志青年走江湖」: ~~[我的朋友梁自存，就这么凭空消失了](https://m.weibo.cn/detail/4370167993942019)~~

---

![MT1ZdLb.jpg](https://i.loli.net/2019/05/10/5cd4d53de3e5f.jpg)
