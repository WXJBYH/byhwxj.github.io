---

layout: post

title: “今天同性恋封完了吗？” “没有”

date: 2018-04-14

categories: Archive

tags: 微博清除同性恋内容

description: 任何同志资讯都将无限期停更。

---

源自微信公号「我的票圈」：~~[“今天同性恋封完了吗？” “没有”](https://mp.weixin.qq.com/s/tnDvW9g3p2Qr7fS4v3LA6Q)~~

作者：票圈君 星星 天沐山

---

昨晚的夜，有点格外漫长。

0 点 53 分，“同志之声”官方微博发布公告宣告将主动「无限期」地停更，任何同志资讯的更新都将暂停。

![tongzhizhisheng-weibo](https://i.imgur.com/3qk3E7I.jpg)

截至发文前，这条微博已经拥有了逾3万的转发，其中包括主持人闾丘露薇、电影人程青松。

在下午四点的时候《好奇心日报》发出了[陈莉雅对“同志之声”创始人兼主编花子乐的采访](https://www.qdaily.com/articles/52153.html)，让我们能更近距离的感受到他们的无奈。（题外话：好奇心日报经常做一些很良心的东西，很佩服。）

“同志之声”之所以能在10年间在同性恋社群中积攒了如此大的影响力，部分是得益于新浪微博给予的合作（比如：蓝V认证）。但在微博清理公告发出前夕，微博团队中某个支持“同志之声”的高管主动致电，希望后者能够暂停更新。

**谁想逃跑，可背后就是深渊。**

![liuyan](https://i.imgur.com/9XFVN5H.png)
<figcaption>《你好渣浪，我是同性恋》的文章留言</figcaption>

![404](https://i.imgur.com/rcv5dBB.jpg)

我昨天发出的文章在发出后不到12个小时便404了，意料之中。

在这12个小时内，包括臧鸿飞、耿乐、陈咏开等人转载了这篇文章。

![comment-1](https://i.imgur.com/KkGhTQT.jpg)

![comment-2](https://i.imgur.com/mNq9qls.png)

![comment-3](https://i.imgur.com/FjASEOX.jpg)

12个小时，109万阅读量，5万个赞，微博转发超过7万。

我认为这是109万个人在默默关注者这件事，

至少5万个微信号反对微博对同性恋的封杀，

超过7万个微博账号用实际行动告诉身边的人：

**“我拒绝沉默，我很骄傲。**

![阅读情况](https://i.imgur.com/K6uXumI.jpg)

在这12个小时内，更多的人站了出来。

连夜在话题 #我是同性恋# 下，纷纷现身说法，发出自己的声音。

 以下微博截图均已获得原博主授权

@以陌叔叔

![yimoshushu](https://i.imgur.com/6TyeIZH.jpg)

@竹顶针
![zhuzhending](https://i.imgur.com/GmQEBm7.jpg)

@夏树
![xiashu](https://i.imgur.com/1DSYDSt.jpg)

@澜也_
![lanye](https://i.imgur.com/kYe1NfI.jpg)

@陳振森森
![chenzhensensen](https://i.imgur.com/XKapLO3.jpg)

@Mew_Wzh
![mew_wzh](https://i.imgur.com/2Q8CyD1.jpg)

@合法片
![hefapian](https://i.imgur.com/6yrrAbl.jpg)

@郑南七白
![zhengnanqibai](https://i.imgur.com/ZKDNJXX.jpg)

@浩枫的无柜之家
![haofengdewujuzhijia](https://i.imgur.com/0FIFsAi.jpg)

@灰嘴入海口
![huizuiruhaikou](https://i.imgur.com/nG8TpbN.jpg)

@Naomi_XLT
![naomi_xlt](https://i.imgur.com/bkhWsxi.jpg)

@赵为御
![zhaoweiyu](https://i.imgur.com/Pr9ioyi.jpg)

@陈咏开的微博在此
![chenyongkai](https://i.imgur.com/kd0Z2VI.jpg)

@八百伊万礼
![babaiyiwanli](https://i.imgur.com/MZ6UdlZ.jpg)

下午 4 点 20 分左右，话题#我是同性恋# 带着无数故事，已经遭到了删除，最终累积阅读量停留在 2.4 亿。

这个数量是我第一次能够切身体会到的声量。

震撼到我的不是冰冷的数据，而是数字背后每一个勇敢站出来的人。

谢谢你们。

![#我是同性恋#](https://i.imgur.com/PTRdzbB.jpg)

以前觉得「就算再小，也要呐喊」。

而现在，我终于感觉不再是一个人了。

愿微弱的星辰最后汇聚成庞大的星河。

原每个同性恋都能够真实而自由的活着。

![piaoquanxueyan](https://i.imgur.com/ZYtnFML.jpg)

如果爱一个人有罪，就判决我罪该万死。
