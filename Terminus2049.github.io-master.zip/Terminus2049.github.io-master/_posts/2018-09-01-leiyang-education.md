---

layout: post

title: 昨天，湖南耒阳，令人揪心的“开学第一课”⋯⋯

categories: Archive

date: 2018-09-01

tags: 耒阳教育

description: 湖南耒阳市，政府把公立学校5-6年级的学生分流到民办学校，家长被迫承担高昂学费。学校刚装修，甲醛超标。家长被逼上相关单位讨说法。

---

原文来自微信「金口娱言」：~~[昨天，湖南耒阳，令人揪心的“开学第一课”⋯⋯](https://mp.weixin.qq.com/s/GeeTwRs8LHVpYhSA907Shw)~~

---

当地网友：事情经过，大致如下。湖南耒阳市，政府把公立学校5-6年级的学生分流到民办学校，家长被迫承担高昂学费。学校刚装修，甲醛超标。家长被逼上相关单位讨说法，结果。。。。

![event01](https://i.loli.net/2018/09/02/5b8b5debbe3e0.jpeg)

![event02](https://i.loli.net/2018/09/02/5b8b5e0f56ade.jpeg)

![event03](https://i.loli.net/2018/09/02/5b8b5e20d952f.jpeg)

![收费标准](https://i.loli.net/2018/09/02/5b8b5e31d4123.jpeg)

![event04](https://i.loli.net/2018/09/02/5b8b5e42c0e6c.jpeg)

![event05](https://i.loli.net/2018/09/02/5b8b5e5332e7d.jpeg)

![教育局通知](https://i.loli.net/2018/09/02/5b8b5e6d513a2.jpeg)

![耒阳生活圈](https://i.loli.net/2018/09/02/5b8b5e800884b.jpeg)

![event06](https://i.loli.net/2018/09/02/5b8b5e9308035.jpeg)

![event07](https://i.loli.net/2018/09/02/5b8b5ead55cf3.jpeg)

![event08](https://i.loli.net/2018/09/02/5b8b5ebc8c806.jpeg)

![event09](https://i.loli.net/2018/09/02/5b8b5ece08cf6.jpeg)

![耒阳在线](https://i.loli.net/2018/09/02/5b8b5ee8313b7.jpeg)

![帖子](https://i.loli.net/2018/09/02/5b8b5efab571e.jpeg)

![event10](https://i.loli.net/2018/09/02/5b8b5f10dc24e.jpeg)

![微博01](https://i.loli.net/2018/09/02/5b8b5f24402d4.jpeg)

![微博02](https://i.loli.net/2018/09/02/5b8b5f372cf1c.jpeg)

![微信群](https://i.loli.net/2018/09/02/5b8b5f4c3a266.jpeg)

![wechatgroup](https://i.loli.net/2018/09/02/5b8b5f63a0a4f.jpeg)

![微博03](https://i.loli.net/2018/09/02/5b8b5f75dccfd.jpeg)

![微博04](https://i.loli.net/2018/09/02/5b8b5f8d8fe70.jpeg)
