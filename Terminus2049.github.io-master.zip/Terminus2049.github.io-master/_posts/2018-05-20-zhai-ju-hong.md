---

layout: post

title: 中南财经政法大学教授翟桔红被撤职

categories: Archive

date: 2018-05-20 22:00

tags: 翟桔红

description: “4月25日下午，翟桔红在行为管理学本科1701班讲授《政治学原理》课程中‘政府结构与功能’时，偏离教材、教学大纲和课件，错误解释我国宪法修改情况，错误介绍我国国有企业产权制度，妄议我国人民代表大会制度，片面介绍其他国家和地区政治制度，在学生中产生了负面影响。”

---

原文来自豆瓣广播，~~[已被404](https://www.douban.com/people/1508253/status/2162714557/)~~

---

注：翟桔红的著作《违宪审查与民主制的平衡》，已被豆瓣移除。

<https://book.douban.com/subject/20501883/>


![01.jpg](https://i.loli.net/2018/05/23/5b053a8757655.jpg)

![02.jpg](https://i.loli.net/2018/05/23/5b053a875644e.jpg)

![03.jpg](https://i.loli.net/2018/05/23/5b053a878c1bd.jpg)
