---

layout: post

title: 今天和昨天，六安戴着手铐的教师和跪在地上的教师都让我们看着泪目……

categories: Archive

date: 2018-05-27 23:30

tags: 教师集体讨薪

image_feature: "https://i.imgur.com/wHcbkB5.jpg"

description: 今天中午开始六安各地的微信、微博和社交媒体疯传教师集体讨薪被抓的图文和视频，警方抓捕数名非法集会游行的讨薪教师并发生激烈冲突。

---

原文来自舒城365:~~[今天和昨天，六安戴着手铐的教师和跪在地上的教师都让我们看着泪目……](https://mp.weixin.qq.com/s/P0_GqoYsq5FyZtuN7MgF6w)~~

---

今天和昨天

网络上热传的

关于六安教师的信息都火遍全国

今天中午开始

六安各地的微信、微博和社交媒体疯传

教师集体讨薪被抓的图文和视频，

警方抓捕数名非法集会游行

的讨薪教师并发生激烈冲突。

详细情节不得而知，

以官方发布为准。

![](https://i.imgur.com/w9MnE6M.jpg)

这位女教师在冲突中被送往医院抢救！

![](https://i.imgur.com/bpKEvph.jpg)

相关话题在微博瞬间成为热搜

阅读人数截止本文发稿时

就已经超过180多万

相对应的热搜榜第一位

也是关于教育的话题

![](https://i.imgur.com/2AFG7HP.jpg)

![](https://i.imgur.com/NvLgKgd.jpg)

微信及朋友圈也在疯狂转发

![](https://i.imgur.com/qkx2ces.jpg)

据传，

这是六安金安裕安两区

包括所辖乡镇的教师们

在向主管部门

讨要被拖欠一年多的工资！

![](https://i.imgur.com/ERBAc5c.jpg)

![](https://i.imgur.com/mxtwvxC.jpg)

![](https://i.imgur.com/sZkOo2M.jpg)

![](https://i.imgur.com/p1yUGmu.jpg)

![](https://i.imgur.com/Tb4JVYL.jpg)

![](https://i.imgur.com/ldGZr9w.jpg)

![](https://i.imgur.com/AYiU7rD.jpg)

![](https://i.imgur.com/cLMM9si.jpg)

一位女教师被几位警员紧紧抓住

集体讨薪行为确实于法不合

但是又是什么样的缘由

让人民教师们走上这样一条路径

也值得某些部门的领导们好好想一想

至于这中间是否有腐败和滥用职权的情况

我们不得而知

也不作揣测

只希望这样的事情能够最终得到合理的解决

同样的，在今天之前

六安的另一位教师也火遍了全国各地媒体

![](https://i.imgur.com/EJxHWmS.jpg)

![](https://i.imgur.com/nB9JFsM.jpg)

![](https://i.imgur.com/vHlCnzO.jpg)

![](https://i.imgur.com/PcfXA9R.jpg)

看到老师被带上冰凉的手铐

我们愤慨心痛

看着跪在地上的老师

我们肃然起敬

让教师成为让人羡慕的职业

需要从上至下的落实到实处

从每一件小事做起

![](https://i.imgur.com/w95kseU.jpg)

<figcaption>今年两会期间，教育部陈宝生部长说：确保中小学教师的工资不低于或高于当地公务员的平均工资收入。</figcaption>

![](https://i.imgur.com/jkFboiU.jpg)

<figcaption>陈部长还说：提高教师待遇、提高教师地位、荣誉感，让教师成为令人羡慕的职业；确保政策真正落实，落实到教师的心里面去，让他们脸上充满笑容。</figcaption>

今天的中国

物质条件相比于上个世纪

已经无数倍的富足

但是在精神层面上

我们时常的感觉到贫乏困顿

这也制约着

我们的国家和社会更好发展

中华民族

最终以什么样的形象

屹立于世界民族之林

教育优先发展战略

是最重要的条件和希望

而何时才能真正贯彻落实？

我们和全国的教师一起

翘首以待！

文中图片及部分文字来源于网络，不代表舒城365观点，仅供参考。
