---

layout: post

title: 紧急关注北大岳昕同学被施压情况！

date: 2018-04-23 11:00

categories: Archive

tags: 声援岳昕

description: 北大学生申请信息公开，被学院约谈。

---

信息源自微信公号「现代资本主义研究」：~~[紧急关注北大岳昕同学被施压情况！](https://mp.weixin.qq.com/s/BpcPRk1GpipNBBSMpJAnKw)~~

---

![](https://i.imgur.com/ZuYdvfM.jpg)

朋友圈消息出现在今早，那么岳昕同学要求北京大学公开什么消息呢？（《中国青年报》[完整相关报道](http://news.cyol.com/yuanchuang/2018-04/07/content_17079555.htm)

![](https://i.imgur.com/5fkpFHg.jpg)

![](https://i.imgur.com/EBhWARO.jpg)

![](https://i.imgur.com/P93Uevv.jpg)

由于北京大学至今没有清晰公布当年对沈阳的进行处分的详细信息，因而岳昕同学参与了向北京大学校方要求公开当年相关信息的申请。那么，敢问北京大学校方，岳昕同学申请信息公开的行为何“罪”之有呢？更何况，在北京大学网站上就赫然挂着信息公开的相关文件！

![](https://i.imgur.com/RqlmJjC.jpg)
<figcaption>http://xxgk.pku.edu.cn/xxgkzd/45570.htm</figcaption>

有同学和岳昕同学私聊了解昨晚经过：

![](https://i.imgur.com/P4XaWkv.jpg)
![](https://i.imgur.com/cnXXxea.jpg)


即使北大可以找到千万条理由，拒绝告诉公众当年自己对沈阳进行了怎样的处分，那么，北大某些人员又有什么资格对岳昕同学进行如此严重的骚扰、恐吓？申请公开当年沈阳一事的信息，为什么要遭此等严重的、侵犯基本人身自由的骚扰？哪怕用“法理”做遮羞布都不肯了吗？或者是，觉得“我就是法”？

当然，北大外院某些“辟谣员”已经开始言之凿凿地救“火”了，仿佛“岁月静好”，只是发生了一个“小误会”：

![](https://i.imgur.com/3QCtKLi.jpg)

然而，经与岳昕同学私聊，我们发现这只是在糊弄舆论。岳昕同学依然处于被限制、施压状况：

![](https://i.imgur.com/UdfGOTT.jpg)

在这里，我们想替岳昕同学和家长说几句话，不管学校派了怎样的人说了怎样的话，请你们相信岳昕同学行为的正当性。她既没有危害什么“安全”，也没有破坏什么“秩序”。岳昕同学只是做了一个有正义心的勇敢普通人、普通学生会做的事情。

我们要求北京大学相关人员立刻停止一切对岳昕及相关同学的骚扰、恐吓行为！也希望岳昕的父母做岳昕同学的后方，而不是和学校一道向岳昕同学施压。

请各位读者与我们一道对此事保持持续关注！

![](https://i.imgur.com/vlw5ILY.png)
<figcaption>留言评论</figcaption>
