---

layout: post

title: 岳昕-自我介绍

date: 2018-04-23

categories: Archive

tags: 声援岳昕

description: 岳昕的自我介绍。

---

图片来自豆瓣，原本出处未知

作者：岳昕

---
![自我介绍](https://i.imgur.com/dG9Z7sT.jpg)
